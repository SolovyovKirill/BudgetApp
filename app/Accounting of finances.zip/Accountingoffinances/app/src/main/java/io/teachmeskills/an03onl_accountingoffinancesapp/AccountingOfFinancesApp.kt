package io.teachmeskills.an03onl_accountingoffinancesapp

import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class AccountingOfFinancesApp: Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@AccountingOfFinancesApp)
        }
    }
}